## In this project we extract data from data_file and return filtered and reordered data

## In order to run it please do the following:

> npm run build
> npm start

You can also use the functions by importing them in your project.
In order to get you data ordered call 

> const  reorderd_data  = get_reordered_data(data);

In order to get it filtered use your ordered data:

> const  filtered_data  =  get_filtered_data(reorderd_data);

For now it assumes that your columns arguments are: ["manifest", "schema", "columns"]
and your rows arguments are: ["result", "data_array"]

TBD: I will change it to customizable arguments
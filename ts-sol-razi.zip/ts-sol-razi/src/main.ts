import { data } from "./data_file";

type Row = (string | null)[];
type Column = string;


/**
 * Removes columns that contain only null values from the list of objects.
 * 
 * @param {Record<string, string | null>[]} data - A list of objects representing the rows of data.
 * @returns {Record<string, string | null>[]} - A new list of objects with columns containing only null values removed.
 */
export function get_filtered_data(data: Record<string, string | null>[]): Record<string, string | null>[] {

  if (data.length === 0) return data;

  const cols = Object.keys(data[0]);
  const nonNullCols = cols.filter(col => data.some(row => row[col] !== null));
  let filted_data = data.map(row => {
    const filteredRow: Record<string, string | null> = {};
    nonNullCols.forEach(col => {
        filteredRow[col] = row[col];
    });
    return filteredRow;
  });
  return filted_data;
}


/**
 * Converts rows of data into a list of objects using the columns names as keys.
 * 
 * @param {any} data - The data from the streaming.
 * @returns {Record<string, string | null>[]} - A list of objects representing the rows of data.
 */
export function get_reordered_data(data: any): Record<string, string | null>[] {
  let cols : Column[] = get_cols(data);
  let rows : Row[] = get_rows(data);
  return rows.map(row => {
    const obj: Record<string, any> = {};
    cols.forEach((col, i) => {
        obj[col] = row[i];
    });
    return obj;
  });
}


/**
 * A helper function that returns all rows - list of lists.
 * 
 * @param {any} data - The data from the streaming.
 * @returns {Row[]} - Each row is a list of strings or null.
 */
function get_rows(data: any): Row[] {
  const rows_args: string[] = ["result", "data_array"]; // TODO - get from user
  return data[rows_args[0]][rows_args[1]];
}


/**
 * A helper function that returns all columns names - list of strings.
 * 
 * @param {any} data - The data from the streaming.
 * @returns {Column[]} - A list containing columns names.
 */
function get_cols(data: any): Column[] {
  const cols_args: string[] = ["manifest", "schema", "columns"]; // TODO - get from user
  let cols : { name: string }[] = data[cols_args[0]][cols_args[1]][cols_args[2]];
  let col_names: Column[] = cols.map(item => item.name);
  return col_names;
}


const reorderd_data = get_reordered_data(data);
const filtered_data = get_filtered_data(reorderd_data);
console.log(`Reorded data without filter:`);
console.log(reorderd_data);
console.log(`Reorded filtered data:`);
console.log(filtered_data);
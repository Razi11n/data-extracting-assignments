const data =  {
    statement_id: '01ef3f5c-98c3-1ebe-99c2-1230eeaf8504',
    status: {
      state: 'SUCCEEDED',
    },
    manifest: {
      format: 'JSON_ARRAY',
      schema: {
        column_count: 3,
        columns: [
          {
            name: 'ruleEvaluationId',
            type_text: 'STRING',
            type_name: 'STRING',
            position: 0,
          },
          {
            name: 'timestamp',
            type_text: 'STRING',
            type_name: 'STRING',
            position: 1,
          },
          {
            name: 'ruleEvaluationUuid',
            type_text: 'STRING',
            type_name: 'STRING',
            position: 2,
          },
        ],
      },
      total_row_count: 2,
      truncated: false,
    },
    result: {
      chunk_index: 0,
      row_offset: 0,
      row_count: 2,
      data_array: [
        ['1720165932289', null, null],
        ['1720006873671', '2024-07-03T11:41:13.671Z', null],
      ],
    },
  };

  export {data};
  